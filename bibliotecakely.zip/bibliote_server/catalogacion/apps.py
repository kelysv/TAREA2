from django.apps import AppConfig


class CatalogacionConfig(AppConfig):
    name = 'catalogacion'
